# SPED para python

Biblioteca em Python para exportação dos arquivos do Sistema Público de Escrituração Digital (SPED) em formato de uma planilha Excel.

## Requisitos

- python

## Como instalar

    $ pip install spedlib